public class Test1 {
 public String  A(){
     String a="helloWorld1";
     return a;

    }
}
