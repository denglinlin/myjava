public class Test2 {
    public String B(){
        String b="helloWorld2";
        return b;
    }
}
