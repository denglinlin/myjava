
public class M {
    public static  void  main(String [] args){
     ServerSocketDemo serverSocketDemo=new ServerSocketDemo();
     serverSocketDemo.Connection();
    }
}
