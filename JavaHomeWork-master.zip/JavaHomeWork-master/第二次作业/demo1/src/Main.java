public class Main {
public static void main(String [] args){
    ServerSocketDemo serverSocketDemo=new ServerSocketDemo();
    serverSocketDemo.Connection();
}
}
